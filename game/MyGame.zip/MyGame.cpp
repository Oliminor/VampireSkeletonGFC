#include "MyGame.h"

using namespace std;

CMyGame::CMyGame(void) { score = 0;}

CMyGame::~CMyGame(void) {}


// --------  game initialisation --------
void CMyGame::OnInitialize()
{
	// Loading graphics and sound assets
	cout << "Loading assets" << endl;
	
	font.LoadDefault(); 
	
	CTexture::smooth=true;
	
	// enable lighting
	Light.Enable();

	// load abarlith model
	player.LoadModel("Abarlith/Abarlith.md2"); 
	player.SetScale( 3.5f);
	
	// todo: load grass model
	grass.LoadModel("grass/grass.obj", "grass/grass.tga");
	grass.SetScale(1.5f);
	
	// todo: load box model
	box.LoadModel("box/box.obj", "box/box.bmp");
	box.SetScale(7.0f);
	
	// todo: load coin model
	coin.LoadModel("coin/coin.obj", "coin/coin.bmp");
	coin.SetScale(7.0f);
	
	// todo: load cobra model
	cobra.LoadModel("cobra/cobra.md2", "cobra/cobra.bmp");
	cobra.SetScale(5.0f);
	
	// todo: load python model
	python.LoadModel("python/python.md2", "python/python.bmp");
	python.SetScale(5.0f);
	
	// load screen sprite image
	screen.LoadImage("startScreen.bmp");
	screen.SetPosition(Width/2.0f, Height/2.0f);

	
	// load floor texture
	floor.LoadTexture("grass.bmp");
	floor.SetTiling(true);
	
	
	// player health bar
	hbar.SetSize(30,5);
	hbar.SetHealth(100);
	
}

	
void CMyGame::OnStartLevel(int level)
{
	// set size of the game world
	floor.SetSize(6000, 6000);

	// todo: set box position, size and motion
	box.SetPosition(200, 25, 200);

	// player position and player health
	player.SetPosition(100, 100, 100); player.SetStatus(0);
	player.SetHealth(100);

	// todo: set python position and speed
	python.PlayAnimation(1, 8, 7, true);
	python.SetSpeed(100);
	python.SetPosition(3000 - rand() % 6000, 25, 3000 - rand() % 6000);

	score = 0;

	// todo: clearing lists
	grassList.delete_all();
	coinList.delete_all();
	cobraList.delete_all();


	// todo: adding grass
		for (int i = 0; i < 200; i++)
		{
			CModel* pGrass = grass.Clone();
			pGrass->SetPosition(3000 - rand() % 6000, 25, 3000 - rand() % 6000);
			pGrass->SetRotation(rand() % 360); //Not in the task, just for more randomness
			grassList.push_back(pGrass);
		}


	// todo: adding coins
	for (int i = 0; i < 50; i++)
	{
		CModel* pCoin = coin.Clone();
		pCoin->SetPosition(3000 - rand() % 6000, 25, 3000 - rand() % 6000);
		pCoin->SetRotation(rand() % 360); //Not in the task, just for more randomness
		pCoin->SetOmega(50);
		coinList.push_back(pCoin);
	}


	// todo: adding cobras
	for (int i = 0; i < 30; i++)
	{
		CModel* pCobra = cobra.Clone();
		pCobra->SetPosition(3000 - rand() % 6000, 25, 3000 - rand() % 6000);
		pCobra->SetRotation(rand() % 360); //Not in the task, just for more randomness
		cobraList.push_back(pCobra);
	}
}

// Game Logic in the OnUpdate function called every frame @ 30 fps

void CMyGame::OnUpdate() 
{
	if (IsMenuMode() || IsGameOver()) return;
	
	long t =  GetTime();
	
	// --- updating models ----
	box.Update(t);

	python.Update(t);
	
	for (CModel* coin : coinList) coin->Update(t);

	for (CModel* cobra : cobraList) cobra->Update(t);
	
	PlayerControl();	

	GameLogic();
}

void CMyGame::PlayerControl()
{
	
	player.Update( GetTime());
	
	if (IsKeyDown(SDLK_w) || player.IsAutoMoving())
	{
      player.SetSpeed(500);
	}
	else player.SetSpeed(0);
	
	
	// collision between box and player
	if (player.HitTestFront(&box)) 
	{
		player.SetSpeed(0);
	}
	
	// play running sequence when UP key is pressed
	// otherwise play standing sequence
	
	if (IsKeyDown(SDLK_w) || player.IsAutoMoving() || player.GetSpeed() > 0)  player.PlayAnimation(40,45,7,true);
	else player.PlayAnimation(1,39,7,true);
	
    
    if (player.GetHealth() <= 0) GameOver();
	
}

void CMyGame::GameLogic()
{
	// Coin logic
	for (CModel* coin : coinList)
	{
		if (player.HitTest(coin) && player.GetStatus() < 5)
		{
			coin->Delete();
			player.SetStatus(player.GetStatus() + 1);
		}
	}
	coinList.delete_if(deleted);

	// Return coin to the box logic
	if (player.HitTest(&box))
	{
		score += player.GetStatus();
		player.SetStatus(0);

		player.SetHealth(100);
	}

	// Cobra game logic
	for (CModel* cobra : cobraList)
	{
		if (player.HitTest(cobra))
		{
			player.SetHealth(player.GetHealth() - 1);

			cobra->SetStatus(1);
			cobra->PlayAnimation(8, 16, 7, false); // attack animation played once only
			cobra->SetRotationToPoint(player.GetX(),  player.GetZ()); //  rotate  towards player
		}
	}

	// Python game logic
	python.SetRotationToPoint(player.GetX(), player.GetZ());
	python.SetDirection(python.GetRotation());

	if (player.HitTest(&python)) player.SetHealth(player.GetHealth() - 1);
}


//-----------------  Draw 2D overlay ----------------------
void CMyGame::OnDraw(CGraphics* g)
{
	if (IsMenuMode()) 
	{
		// draw screen here
		screen.Draw(g);
		
		 
		return;
	}
	
	// draw GTEC 3D text
	font.SetColor( CColor::Blue()); font.SetSize( 32); font.DrawText( Width-200,Height-50, "Explorer" );
	// draw score
	font.SetColor( CColor::Red()); font.DrawNumber(10,Height-100, score);

	// draw picked up coin number
	font.SetColor(CColor::Yellow()); font.DrawNumber(10, Height - 50, player.GetStatus());

	// draw "at full capacity"
	if (player.GetStatus() == 5)
	{
		font.SetColor(CColor::Yellow()); font.SetSize(32); font.DrawText(Width / 2, Height / 2, "At full capacity!");
	}
	
	// drawing the healthbar (which is a sprite object drawn in 2D)
	CVector pos=WorldToScreenCoordinate(player.GetPositionV());
	hbar.SetPosition(pos.x,pos.y+50); 
	hbar.SetHealth( player.GetHealth());
	hbar.Draw(g);
	
	
	
	// draw GAME OVER if game over
   	if (IsGameOver())
   	{
		font.SetSize(64); font.SetColor( CColor::Red()); font.DrawText( 250,300, "GAME OVER");	
	}
	
}

void CMyGame::CameraControl(CGraphics* g)
{
	// game world tilt
    float tilt=70; 
    float scale=1.0f;
	
	// ------ Global Transformation Functions -----
	
	//glTranslatef(0,-100,0);  // move game world down 
	glRotatef(tilt,1,0,0);			// tilt game world around x axis
    glScalef(scale,scale,scale);			// scaling the game world
	
	// ---- 3rd person camera setup -----
	//glRotatef( rotation,0,1,0);		// rotate game world around y axis
	glTranslatef(-player.GetX(), 0, -player.GetZ());    // position game world
		
	UpdateView();
	Light.Apply();
}


// ----------------   Draw 3D world -------------------------
void CMyGame::OnRender3D(CGraphics* g)
{
	CameraControl(g);
	
	// ------- Draw your 3D Models here ----------
	
	floor.Draw(g); // if true with grid, false without grid
	
	player.Draw(g);
	
	box.Draw(g);

	python.Draw(g);

	for (CModel* grasses : grassList) grasses->Draw(g);

	for (CModel* coin : coinList) coin->Draw(g);
	
	for (CModel* cobra : cobraList)
	{
		if (cobra->GetStatus() == 1)
		cobra->Draw(g);
	}
	
	//ShowBoundingBoxes();
	ShowCoordinateSystem();
}





// called at the start of a new game - display menu here
void CMyGame::OnDisplayMenu()
{
 
}

// called when Game Mode entered
void CMyGame::OnStartGame()
{
     OnStartLevel(1);	  
}


// called when Game is Over
void CMyGame::OnGameOver()
{
	
}

// one time termination code
void CMyGame::OnTerminate()
{
	
}

// -------    Keyboard Event Handling ------------

void CMyGame::OnKeyDown(SDLKey sym, SDLMod mod, Uint16 unicode)
{
	if (sym == SDLK_SPACE)
	{
		if (IsPaused()) ResumeGame();
		else PauseGame();

	}
	if (sym == SDLK_F2) NewGame();
  
}

void CMyGame::OnKeyUp(SDLKey sym, SDLMod mod, Uint16 unicode)
{
	
}

// -----  Mouse Events Handlers -------------

void CMyGame::OnMouseMove(Uint16 x,Uint16 y,Sint16 relx,Sint16 rely,bool bLeft,bool bRight,bool bMiddle)
{
	CVector pos=ScreenToFloorCoordinate(x,y);
	
	player.SetDirectionAndRotationToPoint(pos.x,pos.z);
	
}

void CMyGame::OnLButtonDown(Uint16 x,Uint16 y)
{    
   if (IsMenuMode()) StartGame();
}

void CMyGame::OnLButtonUp(Uint16 x,Uint16 y)
{
}

void CMyGame::OnRButtonDown(Uint16 x,Uint16 y)
{
}

void CMyGame::OnRButtonUp(Uint16 x,Uint16 y)
{
}

void CMyGame::OnMButtonDown(Uint16 x,Uint16 y)
{
}

void CMyGame::OnMButtonUp(Uint16 x,Uint16 y)
{
}
